package com.dicoding.picodiploma.tresh20.response

import com.google.gson.annotations.SerializedName

data class RegistResp(
    @field:SerializedName("msg")
    val msg: String
)
